const board = document.getElementById("chessboard");
const toggleBtn = document.getElementById("toggleTheme");

// Classic 2D Unicode chess pieces
const boardSetup = [
  ['♜','♞','♝','♛','♚','♝','♞','♜'],
  ['♟','♟','♟','♟','♟','♟','♟','♟'],
  ['','','','','','','',''],
  ['','','','','','','',''],
  ['','','','','','','',''],
  ['','','','','','','',''],
  ['♙','♙','♙','♙','♙','♙','♙','♙'],
  ['♖','♘','♗','♕','♔','♗','♘','♖']
];

function createBoard() {
  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const square = document.createElement("div");
      square.classList.add("square");
      square.classList.add((row + col) % 2 === 0 ? "light" : "dark");
      square.textContent = boardSetup[row][col];
      board.appendChild(square);
    }
  }
}

toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark-mode");
});

createBoard();
